## CombatDebugOverlay - Visual debug overlay for battle system.
## Toggle with F3 key to show combat information for all regiments.
##
## Displays:
## - Morale bars (colored by value)
## - Soldier count (current/max)
## - Facing direction arrow
## - "FLANKED!" indicator when being flanked
## - AI state text for AI-controlled units
## - Lines from regiments to their current targets
class_name CombatDebugOverlay
extends CanvasLayer


## Reference to the draw control node
var draw_control: Control

## Camera reference for 3D to 2D projection
var camera: Camera3D

## Toggle state
var is_enabled: bool = false

## Track flanked regiments (cleared when no longer being flanked)
var flanked_regiments: Dictionary = {}  # Regiment -> { flanker: Regiment, is_rear: bool, timer: float }

## Flank indicator duration
const FLANK_INDICATOR_DURATION: float = 2.0

## Colors
const COLOR_MORALE_HIGH: Color = Color(0.2, 0.9, 0.2, 1.0)      # Green - above 60%
const COLOR_MORALE_MED: Color = Color(0.9, 0.9, 0.2, 1.0)       # Yellow - 30-60%
const COLOR_MORALE_LOW: Color = Color(0.9, 0.2, 0.2, 1.0)       # Red - below 30%
const COLOR_MORALE_BG: Color = Color(0.1, 0.1, 0.1, 0.8)        # Background
const COLOR_SOLDIER_TEXT: Color = Color(1.0, 1.0, 1.0, 1.0)     # White
const COLOR_FLANKED: Color = Color(1.0, 0.3, 0.0, 1.0)          # Orange-red
const COLOR_AI_STATE: Color = Color(0.6, 0.8, 1.0, 1.0)         # Light blue
const COLOR_FACING_ARROW: Color = Color(0.8, 0.8, 0.2, 0.9)     # Yellow
const COLOR_TARGET_LINE: Color = Color(1.0, 0.4, 0.4, 0.6)      # Red (semi-transparent)
const COLOR_TARGET_LINE_PLAYER: Color = Color(0.4, 0.8, 1.0, 0.6)  # Blue for player units
const COLOR_MELEE_LINE: Color = Color(1.0, 0.6, 0.0, 0.9)        # Orange for active melee pairs
const COLOR_MELEE_LINE_GLOW: Color = Color(1.0, 0.8, 0.2, 0.5)   # Yellow glow around melee lines

## Expected engagement distance (must match Regiment.ENGAGEMENT_DISTANCE)
const ENGAGEMENT_DISTANCE: float = 3.0

## Toggle per-frame engagement position logging (F4)
var log_engage_deltas: bool = false

## UI sizing
const MORALE_BAR_WIDTH: float = 80.0
const MORALE_BAR_HEIGHT: float = 10.0
const MORALE_BAR_OFFSET_Y: float = -45.0
const MORALE_STATE_OFFSET_Y: float = -58.0
const SOLDIER_COUNT_OFFSET_Y: float = -28.0
const ARROW_LENGTH: float = 25.0
const ARROW_HEAD_SIZE: float = 8.0
const FLANKED_OFFSET_Y: float = -72.0
const AI_STATE_OFFSET_Y: float = -87.0
const UNIT_NAME_OFFSET_Y: float = -102.0
const COLOR_UNIT_NAME_ENEMY: Color = Color(1.0, 0.3, 0.3, 1.0)      # Red for enemies
const COLOR_UNIT_NAME_PLAYER: Color = Color(0.3, 0.7, 1.0, 1.0)     # Blue for player
const COLOR_MORALE_STATE_STEADY: Color = Color(0.3, 0.9, 0.3, 1.0)  # Green
const COLOR_MORALE_STATE_WAVERING: Color = Color(0.9, 0.9, 0.3, 1.0) # Yellow
const COLOR_MORALE_STATE_SHAKEN: Color = Color(0.9, 0.6, 0.2, 1.0)   # Orange
const COLOR_MORALE_STATE_BROKEN: Color = Color(0.9, 0.2, 0.2, 1.0)   # Red


func _ready() -> void:
	layer = 100  # Render on top of everything

	# Create the Control node for drawing
	draw_control = Control.new()
	draw_control.name = "DrawControl"
	draw_control.set_anchors_preset(Control.PRESET_FULL_RECT)
	draw_control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(draw_control)

	# Connect draw function
	draw_control.draw.connect(_on_draw)

	# Connect to BattleSignals for flank detection
	if BattleSignals:
		BattleSignals.unit_flanked.connect(_on_unit_flanked)

	# Start disabled but print reminder
	draw_control.visible = false
	# Delayed reminder so it shows after other startup messages
	get_tree().create_timer(1.5).timeout.connect(func():
		print("")
		print("=== COMBAT DEBUG ===")
		print("Press F3 to toggle combat debug overlay (morale, flanking, AI state)")
		print("Press F4 to toggle engagement distance logging")
		print("====================")
		print("")
	)


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F3:
			toggle_overlay()
		elif event.keycode == KEY_F4:
			toggle_engage_logging()


func toggle_overlay() -> void:
	is_enabled = not is_enabled
	draw_control.visible = is_enabled

	if is_enabled:
		print("CombatDebugOverlay: ENABLED (F3 to toggle)")
	else:
		print("CombatDebugOverlay: DISABLED")


func toggle_engage_logging() -> void:
	log_engage_deltas = not log_engage_deltas
	if log_engage_deltas:
		print("CombatDebugOverlay: Engage delta logging ENABLED (F4 to toggle)")
	else:
		print("CombatDebugOverlay: Engage delta logging DISABLED")


func _process(delta: float) -> void:
	if not is_enabled:
		return

	# Find camera if not cached
	if not camera or not is_instance_valid(camera):
		camera = get_viewport().get_camera_3d()

	# Update flank timers
	_update_flank_timers(delta)

	# Request redraw
	draw_control.queue_redraw()


func _update_flank_timers(delta: float) -> void:
	## Update flank indicator timers and remove expired ones.
	var to_remove: Array = []

	for regiment in flanked_regiments:
		if not is_instance_valid(regiment):
			to_remove.append(regiment)
			continue

		flanked_regiments[regiment]["timer"] -= delta
		if flanked_regiments[regiment]["timer"] <= 0:
			to_remove.append(regiment)

	for regiment in to_remove:
		flanked_regiments.erase(regiment)


func _on_unit_flanked(flanked: Regiment, flanker: Regiment, is_rear: bool) -> void:
	## Called when a unit is flanked - track for display.
	flanked_regiments[flanked] = {
		"flanker": flanker,
		"is_rear": is_rear,
		"timer": FLANK_INDICATOR_DURATION
	}


func _on_draw() -> void:
	## Main draw callback - renders all debug info.
	if not is_enabled or not camera:
		return

	# Draw active melee pair connections first (so they appear behind other UI)
	_draw_melee_pairs()

	# Get all regiments
	var all_regiments: Array = get_tree().get_nodes_in_group("all_regiments")

	for regiment in all_regiments:
		if not regiment is Regiment:
			continue
		if not is_instance_valid(regiment):
			continue
		if regiment.state == Regiment.State.DEAD:
			continue

		_draw_regiment_debug(regiment)

		# Log engagement position deltas if enabled
		if log_engage_deltas and regiment.state == Regiment.State.ENGAGING:
			_log_engage_delta(regiment)


func _draw_regiment_debug(regiment: Regiment) -> void:
	## Draw all debug info for a single regiment.

	# Get screen position
	var screen_pos: Vector2 = _world_to_screen(regiment.global_position)
	if screen_pos == Vector2.ZERO:
		return  # Behind camera or off-screen

	# Draw morale bar
	_draw_morale_bar(regiment, screen_pos)

	# Draw soldier count
	_draw_soldier_count(regiment, screen_pos)

	# Draw facing arrow
	_draw_facing_arrow(regiment, screen_pos)

	# Draw flanked indicator
	if regiment in flanked_regiments:
		_draw_flanked_indicator(regiment, screen_pos)

	# Draw AI state (only for AI-controlled units)
	if not regiment.is_player_controlled and regiment.ai_controller:
		_draw_ai_state(regiment, screen_pos)

	# Draw unit name (for identifying units during debug)
	_draw_unit_name(regiment, screen_pos)

	# Draw target line
	_draw_target_line(regiment)


func _draw_morale_bar(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw morale bar above the regiment with percentage and state.
	var bar_pos: Vector2 = screen_pos + Vector2(-MORALE_BAR_WIDTH / 2, MORALE_BAR_OFFSET_Y)

	# Background
	var bg_rect: Rect2 = Rect2(bar_pos, Vector2(MORALE_BAR_WIDTH, MORALE_BAR_HEIGHT))
	draw_control.draw_rect(bg_rect, COLOR_MORALE_BG)

	# Morale fill
	var morale_ratio: float = clampf(regiment.current_morale / 100.0, 0.0, 1.0)
	var fill_width: float = MORALE_BAR_WIDTH * morale_ratio

	# Color based on morale level
	var morale_color: Color
	if regiment.current_morale >= 60.0:
		morale_color = COLOR_MORALE_HIGH
	elif regiment.current_morale >= 30.0:
		morale_color = COLOR_MORALE_MED
	else:
		morale_color = COLOR_MORALE_LOW

	var fill_rect: Rect2 = Rect2(bar_pos + Vector2(1, 1), Vector2(fill_width - 2, MORALE_BAR_HEIGHT - 2))
	draw_control.draw_rect(fill_rect, morale_color)

	# Border
	draw_control.draw_rect(bg_rect, Color.WHITE, false, 1.0)

	# Draw percentage text on the bar
	var percent_text: String = "%d%%" % int(regiment.current_morale)
	var font: Font = ThemeDB.fallback_font
	var font_size: int = 9
	var text_size: Vector2 = font.get_string_size(percent_text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	var text_pos: Vector2 = bar_pos + Vector2(MORALE_BAR_WIDTH / 2 - text_size.x / 2, MORALE_BAR_HEIGHT - 1)
	draw_control.draw_string(font, text_pos + Vector2(1, 0), percent_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.BLACK)
	draw_control.draw_string(font, text_pos, percent_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)

	# Draw morale state text below bar
	_draw_morale_state(regiment, screen_pos)


func _draw_morale_state(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw morale state text (STEADY/WAVERING/SHAKEN/BROKEN) with broken count.
	if not regiment.unit_morale:
		return

	var state_text: String = ""
	var state_color: Color = COLOR_MORALE_STATE_STEADY
	var broken_count: int = 0
	var total_count: int = 0

	# Get state from unit_morale
	if regiment.unit_morale.has_method("get_morale_state"):
		var state: int = regiment.unit_morale.get_morale_state()
		match state:
			0:  # STEADY
				state_text = "STEADY"
				state_color = COLOR_MORALE_STATE_STEADY
			1:  # WAVERING
				state_text = "WAVERING"
				state_color = COLOR_MORALE_STATE_WAVERING
			2:  # SHAKEN
				state_text = "SHAKEN"
				state_color = COLOR_MORALE_STATE_SHAKEN
			3:  # BROKEN
				state_text = "BROKEN"
				state_color = COLOR_MORALE_STATE_BROKEN

	# Get broken count if available
	if regiment.unit_morale.has_method("get_broken_count"):
		broken_count = regiment.unit_morale.get_broken_count()
	if regiment.unit_morale.has_method("get_soldier_count"):
		total_count = regiment.unit_morale.get_soldier_count()

	# Add broken count to state text if any broken
	if broken_count > 0:
		state_text += " (%d/%d broken)" % [broken_count, total_count]

	# Check routing/shattered status
	if regiment.unit_morale.has_method("is_routing") and regiment.unit_morale.is_routing():
		state_text = "ROUTING!"
		state_color = COLOR_MORALE_STATE_BROKEN
	if regiment.unit_morale.has_method("is_shattered") and regiment.unit_morale.is_shattered():
		state_text = "SHATTERED!"
		state_color = Color(0.5, 0.0, 0.0, 1.0)  # Dark red

	var text_pos: Vector2 = screen_pos + Vector2(0, MORALE_STATE_OFFSET_Y)

	var font: Font = ThemeDB.fallback_font
	var font_size: int = 11

	var text_size: Vector2 = font.get_string_size(state_text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	text_pos.x -= text_size.x / 2

	# Draw shadow
	draw_control.draw_string(font, text_pos + Vector2(1, 1), state_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.BLACK)
	# Draw text
	draw_control.draw_string(font, text_pos, state_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, state_color)


func _draw_soldier_count(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw soldier count text.
	var text: String = "%d/%d" % [regiment.current_soldiers, regiment.data.max_soldiers]
	var text_pos: Vector2 = screen_pos + Vector2(0, SOLDIER_COUNT_OFFSET_Y)

	# Get default font
	var font: Font = ThemeDB.fallback_font
	var font_size: int = 12

	# Center the text
	var text_size: Vector2 = font.get_string_size(text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	text_pos.x -= text_size.x / 2

	# Draw shadow
	draw_control.draw_string(font, text_pos + Vector2(1, 1), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.BLACK)
	# Draw text
	draw_control.draw_string(font, text_pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, COLOR_SOLDIER_TEXT)


func _draw_facing_arrow(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw an arrow showing the regiment's facing direction.
	## FLANKING FIX: Arrow flashes red when unit is being flanked.
	var facing_3d: Vector3 = regiment.get_facing_direction()

	# Convert 3D facing to 2D direction (ignore Y, invert Z for screen coordinates)
	var facing_2d: Vector2 = Vector2(facing_3d.x, -facing_3d.z).normalized()

	# Arrow start point (slightly below the unit position)
	var arrow_start: Vector2 = screen_pos + Vector2(0, 5)
	var arrow_end: Vector2 = arrow_start + facing_2d * ARROW_LENGTH

	# FLANKING FIX: Color red if recently flanked, yellow otherwise
	var arrow_color: Color = COLOR_FACING_ARROW
	if regiment in flanked_regiments:
		var timer: float = flanked_regiments[regiment].get("timer", 0.0)
		# Pulse between red and orange for visibility
		var pulse: float = 0.5 + 0.5 * sin(timer * 12.0)
		arrow_color = Color(1.0, pulse * 0.3, 0.0, 1.0)

	# Draw arrow line
	draw_control.draw_line(arrow_start, arrow_end, arrow_color, 2.0)

	# Draw arrow head
	var perpendicular: Vector2 = Vector2(-facing_2d.y, facing_2d.x)
	var head_base: Vector2 = arrow_end - facing_2d * ARROW_HEAD_SIZE
	var head_left: Vector2 = head_base + perpendicular * (ARROW_HEAD_SIZE / 2)
	var head_right: Vector2 = head_base - perpendicular * (ARROW_HEAD_SIZE / 2)

	draw_control.draw_polygon(
		PackedVector2Array([arrow_end, head_left, head_right]),
		PackedColorArray([arrow_color, arrow_color, arrow_color])
	)

	# FLANKING FIX: Draw 45° front-arc cone in transparent green
	var arc_length: float = ARROW_LENGTH * 0.8
	var left_arc: Vector2 = facing_2d.rotated(deg_to_rad(-45)) * arc_length
	var right_arc: Vector2 = facing_2d.rotated(deg_to_rad(45)) * arc_length
	var arc_color: Color = Color(0.2, 0.8, 0.2, 0.4)
	draw_control.draw_line(arrow_start, arrow_start + left_arc, arc_color, 1.0)
	draw_control.draw_line(arrow_start, arrow_start + right_arc, arc_color, 1.0)


func _draw_flanked_indicator(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw "FLANKED!" or "REAR!" indicator.
	var flank_data: Dictionary = flanked_regiments[regiment]
	var is_rear: bool = flank_data["is_rear"]
	var timer: float = flank_data["timer"]

	# Pulse effect based on timer
	var alpha: float = 0.5 + 0.5 * sin(timer * 10.0)
	var color: Color = COLOR_FLANKED
	color.a = alpha

	var text: String = "REAR!" if is_rear else "FLANKED!"
	var text_pos: Vector2 = screen_pos + Vector2(0, FLANKED_OFFSET_Y)

	var font: Font = ThemeDB.fallback_font
	var font_size: int = 14

	var text_size: Vector2 = font.get_string_size(text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	text_pos.x -= text_size.x / 2

	# Draw with shadow
	draw_control.draw_string(font, text_pos + Vector2(1, 1), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0, 0, 0, alpha))
	draw_control.draw_string(font, text_pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)


func _draw_ai_state(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw AI state for AI-controlled units.
	var ai: CommanderAI = regiment.ai_controller
	if not ai:
		return

	# Build state text
	var state_text: String = ""

	# Current stance
	var stance_names: Array[String] = ["PASSIVE", "DEFENSIVE", "AGGRESSIVE", "FLANKING", "SKIRMISH"]
	if ai.current_stance >= 0 and ai.current_stance < stance_names.size():
		state_text = stance_names[ai.current_stance]

	# Current target
	if ai.current_target and is_instance_valid(ai.current_target):
		state_text += " -> " + ai.current_target.name

	# Check for routing
	if ai.blackboard.get("is_routing", false):
		state_text = "ROUTING!"

	# Regiment state
	match regiment.state:
		Regiment.State.IDLE:
			if state_text.is_empty():
				state_text = "IDLE"
		Regiment.State.MARCHING:
			state_text = "MARCH: " + state_text
		Regiment.State.ENGAGING:
			state_text = "ENGAGE: " + state_text
		Regiment.State.ROUTING:
			state_text = "ROUTING!"
		Regiment.State.RALLYING:
			state_text = "RALLYING..."

	var text_pos: Vector2 = screen_pos + Vector2(0, AI_STATE_OFFSET_Y)

	var font: Font = ThemeDB.fallback_font
	var font_size: int = 11

	var text_size: Vector2 = font.get_string_size(state_text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	text_pos.x -= text_size.x / 2

	# Draw with shadow
	draw_control.draw_string(font, text_pos + Vector2(1, 1), state_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.BLACK)
	draw_control.draw_string(font, text_pos, state_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, COLOR_AI_STATE)


func _draw_unit_name(regiment: Regiment, screen_pos: Vector2) -> void:
	## Draw unit name above the regiment for identification.
	var unit_name: String = regiment.name

	# Also show soldier count for quick reference
	unit_name += " (%d)" % regiment.current_soldiers

	var text_pos: Vector2 = screen_pos + Vector2(0, UNIT_NAME_OFFSET_Y)

	var font: Font = ThemeDB.fallback_font
	var font_size: int = 13

	var text_size: Vector2 = font.get_string_size(unit_name, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
	text_pos.x -= text_size.x / 2

	# Choose color based on player/enemy
	var text_color: Color = COLOR_UNIT_NAME_PLAYER if regiment.is_player_controlled else COLOR_UNIT_NAME_ENEMY

	# Draw with shadow
	draw_control.draw_string(font, text_pos + Vector2(1, 1), unit_name, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.BLACK)
	draw_control.draw_string(font, text_pos, unit_name, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, text_color)


func _draw_target_line(regiment: Regiment) -> void:
	## Draw a line from this regiment to its current target.
	var target: Regiment = null

	# Get target from AI controller if available
	if regiment.ai_controller and regiment.ai_controller.current_target:
		target = regiment.ai_controller.current_target

	# Also check if in active melee (CombatManager)
	if not target and CombatManager:
		for melee in CombatManager.active_melees:
			if melee.get("attacker") == regiment:
				target = melee.get("defender")
				break
			elif melee.get("defender") == regiment:
				target = melee.get("attacker")
				break

	if not target or not is_instance_valid(target):
		return

	# Get screen positions
	var from_pos: Vector2 = _world_to_screen(regiment.global_position)
	var to_pos: Vector2 = _world_to_screen(target.global_position)

	if from_pos == Vector2.ZERO or to_pos == Vector2.ZERO:
		return

	# Choose color based on player/enemy
	var line_color: Color = COLOR_TARGET_LINE_PLAYER if regiment.is_player_controlled else COLOR_TARGET_LINE

	# Draw dashed line
	_draw_dashed_line(from_pos, to_pos, line_color, 2.0, 8.0, 4.0)

	# Draw small circle at target end
	draw_control.draw_circle(to_pos, 4.0, line_color)


func _draw_dashed_line(from: Vector2, to: Vector2, color: Color, width: float, dash_length: float, gap_length: float) -> void:
	## Draw a dashed line between two points.
	var direction: Vector2 = (to - from).normalized()
	var total_length: float = from.distance_to(to)
	var current_pos: float = 0.0
	var drawing: bool = true

	while current_pos < total_length:
		var segment_length: float = dash_length if drawing else gap_length
		segment_length = minf(segment_length, total_length - current_pos)

		if drawing:
			var start: Vector2 = from + direction * current_pos
			var end: Vector2 = from + direction * (current_pos + segment_length)
			draw_control.draw_line(start, end, color, width)

		current_pos += segment_length
		drawing = not drawing


func _world_to_screen(world_pos: Vector3) -> Vector2:
	## Convert 3D world position to 2D screen position.
	if not camera:
		return Vector2.ZERO

	# Check if point is in front of camera
	var camera_transform: Transform3D = camera.global_transform
	var local_pos: Vector3 = camera_transform.affine_inverse() * world_pos

	if local_pos.z > 0:
		return Vector2.ZERO  # Behind camera

	# Check if point is on screen
	if not camera.is_position_in_frustum(world_pos):
		return Vector2.ZERO

	return camera.unproject_position(world_pos)


func _draw_melee_pairs() -> void:
	## Draw colored lines between all regiments in active melee combat.
	if not CombatManager:
		return

	for melee in CombatManager.active_melees:
		if melee.size() == 0:
			continue

		var attacker = melee.get("attacker")
		var defender = melee.get("defender")

		if not is_instance_valid(attacker) or not is_instance_valid(defender):
			continue

		var from_pos: Vector2 = _world_to_screen(attacker.global_position)
		var to_pos: Vector2 = _world_to_screen(defender.global_position)

		if from_pos == Vector2.ZERO or to_pos == Vector2.ZERO:
			continue

		# Draw glow line (wider, semi-transparent)
		draw_control.draw_line(from_pos, to_pos, COLOR_MELEE_LINE_GLOW, 8.0)
		# Draw main line
		draw_control.draw_line(from_pos, to_pos, COLOR_MELEE_LINE, 3.0)

		# Draw distance text at midpoint
		var mid_pos: Vector2 = (from_pos + to_pos) / 2.0
		var dist_3d: float = attacker.global_position.distance_to(defender.global_position)
		var dist_text: String = "%.1fm" % dist_3d

		var font: Font = ThemeDB.fallback_font
		var font_size: int = 10
		var text_size: Vector2 = font.get_string_size(dist_text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		var text_pos: Vector2 = mid_pos - text_size / 2.0

		# Background for readability
		draw_control.draw_rect(Rect2(text_pos - Vector2(2, 2), text_size + Vector2(4, 4)), Color(0, 0, 0, 0.7))
		draw_control.draw_string(font, text_pos + Vector2(0, font_size), dist_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, COLOR_MELEE_LINE)


func _log_engage_delta(regiment: Regiment) -> void:
	## Log position delta for engaged regiment (for debugging engagement distance issues).
	# Find enemy in melee
	if not CombatManager:
		return

	for melee in CombatManager.active_melees:
		var enemy: Regiment = null
		if melee.get("attacker") == regiment:
			enemy = melee.get("defender")
		elif melee.get("defender") == regiment:
			enemy = melee.get("attacker")

		if enemy and is_instance_valid(enemy):
			var dist: float = regiment.global_position.distance_to(enemy.global_position)
			var error: float = dist - ENGAGEMENT_DISTANCE
			if absf(error) > 0.1:  # Only log significant deltas
				print("[ENGAGE] %s <-> %s: dist=%.2f, error=%.2f" % [regiment.name, enemy.name, dist, error])
			break  # Only log first melee pair for this regiment
